# Medical_Insurance_Price_Prediction


### Data Preprocessing


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import warnings
warnings.filterwarnings("ignore")
```


```python
df = pd.read_csv('insurance.csv')
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>bmi</th>
      <th>children</th>
      <th>smoker</th>
      <th>region</th>
      <th>charges</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>19</td>
      <td>female</td>
      <td>27.900</td>
      <td>0</td>
      <td>yes</td>
      <td>southwest</td>
      <td>16884.92400</td>
    </tr>
    <tr>
      <th>1</th>
      <td>18</td>
      <td>male</td>
      <td>33.770</td>
      <td>1</td>
      <td>no</td>
      <td>southeast</td>
      <td>1725.55230</td>
    </tr>
    <tr>
      <th>2</th>
      <td>28</td>
      <td>male</td>
      <td>33.000</td>
      <td>3</td>
      <td>no</td>
      <td>southeast</td>
      <td>4449.46200</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>male</td>
      <td>22.705</td>
      <td>0</td>
      <td>no</td>
      <td>northwest</td>
      <td>21984.47061</td>
    </tr>
    <tr>
      <th>4</th>
      <td>32</td>
      <td>male</td>
      <td>28.880</td>
      <td>0</td>
      <td>no</td>
      <td>northwest</td>
      <td>3866.85520</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isnull().sum()
```




    age         0
    sex         0
    bmi         0
    children    0
    smoker      0
    region      0
    charges     0
    dtype: int64




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1338 entries, 0 to 1337
    Data columns (total 7 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   age       1338 non-null   int64  
     1   sex       1338 non-null   object 
     2   bmi       1338 non-null   float64
     3   children  1338 non-null   int64  
     4   smoker    1338 non-null   object 
     5   region    1338 non-null   object 
     6   charges   1338 non-null   float64
    dtypes: float64(2), int64(2), object(3)
    memory usage: 73.3+ KB
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>bmi</th>
      <th>children</th>
      <th>charges</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1338.000000</td>
      <td>1338.000000</td>
      <td>1338.000000</td>
      <td>1338.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>39.207025</td>
      <td>30.663397</td>
      <td>1.094918</td>
      <td>13270.422265</td>
    </tr>
    <tr>
      <th>std</th>
      <td>14.049960</td>
      <td>6.098187</td>
      <td>1.205493</td>
      <td>12110.011237</td>
    </tr>
    <tr>
      <th>min</th>
      <td>18.000000</td>
      <td>15.960000</td>
      <td>0.000000</td>
      <td>1121.873900</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>27.000000</td>
      <td>26.296250</td>
      <td>0.000000</td>
      <td>4740.287150</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>39.000000</td>
      <td>30.400000</td>
      <td>1.000000</td>
      <td>9382.033000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>51.000000</td>
      <td>34.693750</td>
      <td>2.000000</td>
      <td>16639.912515</td>
    </tr>
    <tr>
      <th>max</th>
      <td>64.000000</td>
      <td>53.130000</td>
      <td>5.000000</td>
      <td>63770.428010</td>
    </tr>
  </tbody>
</table>
</div>



### Exploratory Data Analysis (EDA)


```python
import matplotlib.pyplot as plt

features = ['sex', 'smoker', 'region']

plt.subplots(figsize=(20, 10))
for i, col in enumerate(features):
	plt.subplot(1, 3, i + 1)

	x = df[col].value_counts()
	plt.pie(x.values,
			labels=x.index,
			autopct='%1.1f%%')

plt.show()
```


    
![png](output_8_0.png)
    



```python
sns.boxplot(df['age'])
```




    <Axes: ylabel='age'>




    
![png](output_9_1.png)
    



```python
sns.boxplot(df['bmi'])
```




    <Axes: ylabel='bmi'>




    
![png](output_10_1.png)
    



```python
# Calculate the first, second, third quartile of the 'bmi' column
Q1=df['bmi'].quantile(0.25)
Q2=df['bmi'].quantile(0.50)
Q3=df['bmi'].quantile(0.75)

# Calculate the Interquartile Range (IQR) as the difference between Q3 and Q1
IQR=Q3-Q1 

# Define the lower bound and upper bound for outliers (any value this is considered an outlier)
lower_bound = Q1-1.5*IQR
upper_bound = Q3+1.5*IQR
print(lower_bound)
print(upper_bound)
```

    13.7
    47.290000000000006
    


```python
# Filter out outliers based on the lower and upper bounds
df = df[(df['bmi'] >= lower_bound) & (df['bmi'] <= upper_bound)]

# Check the shape of the new DataFrame to see how many rows remain
print(df.shape)

# Check again for outliers
sns.boxplot(df['bmi'])
```

    (1329, 7)
    




    <Axes: ylabel='bmi'>




    
![png](output_12_2.png)
    



```python
from sklearn.preprocessing import LabelEncoder

# Label encoding for 'sex' and 'smoker'
le = LabelEncoder()
df['sex'] = le.fit_transform(df['sex'])  # female=0, male=1
df['smoker'] = le.fit_transform(df['smoker'])  # no=0, yes=1

# One-hot encoding for 'region'
df = pd.get_dummies(df, columns=['region'], drop_first=True)

# df = df.replace({True: 1, False: 0})
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>bmi</th>
      <th>children</th>
      <th>smoker</th>
      <th>charges</th>
      <th>region_northwest</th>
      <th>region_southeast</th>
      <th>region_southwest</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>19</td>
      <td>0</td>
      <td>27.900</td>
      <td>0</td>
      <td>1</td>
      <td>16884.92400</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1</th>
      <td>18</td>
      <td>1</td>
      <td>33.770</td>
      <td>1</td>
      <td>0</td>
      <td>1725.55230</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>28</td>
      <td>1</td>
      <td>33.000</td>
      <td>3</td>
      <td>0</td>
      <td>4449.46200</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>1</td>
      <td>22.705</td>
      <td>0</td>
      <td>0</td>
      <td>21984.47061</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>32</td>
      <td>1</td>
      <td>28.880</td>
      <td>0</td>
      <td>0</td>
      <td>3866.85520</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize = (11,7.5))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
plt.show()
```


    
![png](output_14_0.png)
    



```python
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
df[['age', 'bmi', 'children']] = scaler.fit_transform(df[['age', 'bmi', 'children']])
```

### Split Data into Features and Target


```python
x = df.drop('charges', axis = 1)
x.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>bmi</th>
      <th>children</th>
      <th>smoker</th>
      <th>region_northwest</th>
      <th>region_southeast</th>
      <th>region_southwest</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-1.438764</td>
      <td>0</td>
      <td>-0.445670</td>
      <td>-0.907940</td>
      <td>1</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-1.509976</td>
      <td>1</td>
      <td>0.546267</td>
      <td>-0.079764</td>
      <td>0</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-0.797855</td>
      <td>1</td>
      <td>0.416149</td>
      <td>1.576587</td>
      <td>0</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-0.441794</td>
      <td>1</td>
      <td>-1.323542</td>
      <td>-0.907940</td>
      <td>0</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-0.513006</td>
      <td>1</td>
      <td>-0.280065</td>
      <td>-0.907940</td>
      <td>0</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
y = df['charges']
y.head()
```




    0    16884.92400
    1     1725.55230
    2     4449.46200
    3    21984.47061
    4     3866.85520
    Name: charges, dtype: float64




```python
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)
```

### Model Building


```python
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.svm import SVR
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import cross_val_score

# Define a dictionary with the models you want to try
models = {
    "Linear Regression": LinearRegression(),
    "Decision Tree": DecisionTreeRegressor(random_state=42),
    "Random Forest": RandomForestRegressor(random_state=42),
    "Support Vector Regressor": SVR(),
    "Gradient Boosting": GradientBoostingRegressor(random_state=42)
}

results = {}

# Loop over the models
for name, model in models.items():
    # Train the model
    model.fit(x_train, y_train)
    
    # Predictions for test set
    y_pred_test = model.predict(x_test)
    
    # Predictions for train set (to calculate train accuracy)
    y_pred_train = model.predict(x_train)
    
    # Calculate performance metrics
    mae = mean_absolute_error(y_test, y_pred_test)
    mse = mean_squared_error(y_test, y_pred_test)
    r2_train = r2_score(y_train, y_pred_train)  # Train accuracy
    r2_test = r2_score(y_test, y_pred_test)  # Test accuracy
    
    # Cross-Validation Score
    cv_score = np.mean(cross_val_score(model, x, y, cv=5, scoring='r2'))  # Average R² score from CV
    
    # Store the results
    results[name] = {
        "Model": name,
        "Train Accuracy (R²)": r2_train,
        "Test Accuracy (R²)": r2_test,
        "MAE": mae,
        "MSE": mse,
        "CV Score (R²)": cv_score
    }

# Print out the performance of each model
for model_name, metrics in results.items():
    print(f"{model_name} Performance:")
    print(f"  MAE: {metrics['MAE']}")
    print(f"  MSE: {metrics['MSE']}")
    print(f"  Train Accuracy: {metrics['Train Accuracy (R²)']}")
    print(f"  Test Accuracy: {metrics['Test Accuracy (R²)']}")
    print(f"  CV Score (R²): {metrics['CV Score (R²)']}\n")

```

    Linear Regression Performance:
      MAE: 4084.9274845566615
      MSE: 34498730.94686416
      Train Accuracy: 0.7454367820598464
      Test Accuracy: 0.7671119511350495
      CV Score (R²): 0.7461299106571825
    
    Decision Tree Performance:
      MAE: 3080.886418703007
      MSE: 44016186.762958996
      Train Accuracy: 0.9982776767777074
      Test Accuracy: 0.7028631612713698
      CV Score (R²): 0.6852304488992939
    
    Random Forest Performance:
      MAE: 2631.7482219285944
      MSE: 25046677.79519435
      Train Accuracy: 0.9754341497834864
      Test Accuracy: 0.830919232036212
      CV Score (R²): 0.8330749391446121
    
    Support Vector Regressor Performance:
      MAE: 8327.510818619909
      MSE: 162884531.4401294
      Train Accuracy: -0.09505160215743969
      Test Accuracy: -0.0995726415502105
      CV Score (R²): -0.10316347655617437
    
    Gradient Boosting Performance:
      MAE: 2346.9525173339525
      MSE: 19704972.19857316
      Train Accuracy: 0.9011069090191972
      Test Accuracy: 0.8669790916271101
      CV Score (R²): 0.851856658868007
    
    


```python
model.score(x_test,y_test)
```




    0.8669790916271101




```python
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import RandomizedSearchCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_regression

# Example data (replace with your actual dataset)
X, y = make_regression(n_samples=1000, n_features=10, noise=0.1, random_state=42)

# Split the data into training and test sets
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define the model
gbr = GradientBoostingRegressor()

# Define the hyperparameters to tune
param_grid = {
    'n_estimators': [100, 200, 300],
    'learning_rate': [0.01, 0.05, 0.1],
    'max_depth': [3, 4, 5],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'subsample': [0.8, 0.9, 1.0],
    'max_features': ['auto', 'sqrt', 'log2']
}

# Setup RandomizedSearchCV
random_search = RandomizedSearchCV(estimator=gbr, 
                                   param_distributions=param_grid, 
                                   n_iter=50,  # Number of combinations to try
                                   cv=5,       # Cross-validation folds
                                   verbose=2,  
                                   n_jobs=-1,  # Use all available cores
                                   random_state=42)

# Fit the RandomizedSearchCV on the training data
random_search.fit(x_train, y_train)

# Get the best parameters and the best estimator
print("Best Parameters:", random_search.best_params_)
best_gbr = random_search.best_estimator_

# Evaluate the performance on the test set
y_pred = best_gbr.predict(x_test)

# Calculate performance metrics
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

# Print evaluation metrics
print(f"Mean Absolute Error (MAE): {mae}")
print(f"Mean Squared Error (MSE): {mse}")
print(f"R² Score: {r2}")
```

    Fitting 5 folds for each of 50 candidates, totalling 250 fits
    Best Parameters: {'subsample': 0.8, 'n_estimators': 200, 'min_samples_split': 10, 'min_samples_leaf': 4, 'max_features': 'sqrt', 'max_depth': 4, 'learning_rate': 0.1}
    Mean Absolute Error (MAE): 21.136862576632016
    Mean Squared Error (MSE): 712.5909372708488
    R² Score: 0.9577626997955203
    

### Model Evaluation


```python
# Calculate metrics
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
print("MAE:", mean_absolute_error(y_test, y_pred))
print("MSE:", mean_squared_error(y_test, y_pred))
print("R²:", r2_score(y_test, y_pred))
```

    MAE: 21.136862576632016
    MSE: 712.5909372708488
    R²: 0.9577626997955203
    


```python
# Assuming 'model' is your trained model

# Collecting user input
age = int(input("Enter age: "))
sex = int(input("Enter sex (0 for female, 1 for male): "))
bmi = float(input("Enter BMI: "))
children = int(input("Enter number of children: "))
smoker = int(input("Are you a smoker? (0 for No, 1 for Yes): "))

# For region, create a simple selection process
print("Select region:")
print("1. Northwest")
print("2. Southeast")
print("3. Southwest")

region = int(input("Enter the number corresponding to the region: "))

# Initialize region features
region_northwest = 0
region_southeast = 0
region_southwest = 0

# Assign the value to the appropriate region based on user input
if region == 1:
    region_northwest = 1
elif region == 2:
    region_southeast = 1
elif region == 3:
    region_southwest = 1

# Prepare input for prediction
input_data = [[age, sex, bmi, children, smoker, region_northwest, region_southeast, region_southwest]]

# Make prediction
prediction = model.predict(input_data)

# Output the predicted charges
print(f"Predicted medical insurance charges: Rs{prediction[0]}")
```

    Enter age:  15
    Enter sex (0 for female, 1 for male):  1
    Enter BMI:  45
    Enter number of children:  1
    Are you a smoker? (0 for No, 1 for Yes):  1
    

    Select region:
    1. Northwest
    2. Southeast
    3. Southwest
    

    Enter the number corresponding to the region:  1
    

    Predicted medical insurance charges: Rs48938.426151535925
    


```python
from sklearn.metrics import r2_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.tree import DecisionTreeRegressor
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_regression

# 'subsample': 1.0, 'n_estimators': 200, 'min_samples_split': 10, 'min_samples_leaf': 2, 'max_features': 'log2', 'max_depth': 3, 'learning_rate': 0.05}
# Example data (replace with your actual data)
X, y = make_regression(n_samples=100, n_features=4, noise=0.2, random_state=42)

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train Decision Tree model
dt_model = DecisionTreeRegressor()
dt_model.fit(X_train, y_train)

# Train Random Forest model
rf_model = RandomForestRegressor()
rf_model.fit(X_train, y_train)

# Make predictions
y_pred_dt = dt_model.predict(X_test)  # Decision Tree predictions
y_pred_rf = rf_model.predict(X_test)  # Random Forest predictions

# Calculate R² score
r2_dt = r2_score(y_test, y_pred_dt)
r2_rf = r2_score(y_test, y_pred_rf)

# Print the R² scores
print(f"Decision Tree R² Score: {r2_dt}")
print(f"Random Forest R² Score: {r2_rf}")

# Plot the comparison of R² scores
models = ['Decision Tree', 'Random Forest']
r2_scores = [r2_dt, r2_rf]

plt.bar(models, r2_scores, color=['blue', 'green'])
plt.ylabel("R² Score")
plt.title("Comparison of Model Performance")
plt.show()
```

    Decision Tree R² Score: 0.7695646577638047
    Random Forest R² Score: 0.914065079294999
    


    
![png](output_27_1.png)
    



```python

```
